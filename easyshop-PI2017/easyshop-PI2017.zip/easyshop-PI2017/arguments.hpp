//
//  arguments.hpp
//  easyshop-PI2017
//
//  Created by uillian on 24/10/2017.
//  Copyright © 2017 uillian. All rights reserved.
//

#ifndef arguments_hpp
#define arguments_hpp

#include <stdio.h>

#endif /* arguments_hpp */
